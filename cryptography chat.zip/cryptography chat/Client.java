import java.net.*;
import java.io.*;
public class Client {
     Socket socket;
     BufferedReader  br; 
     PrintWriter  out; 

    public Client()
    {
        try {
            System.out.println("sending request to server");
            socket = new Socket("172.20.10.4" , 7778);
            System.out.println("Connected");

            br = new BufferedReader(new InputStreamReader(socket.getInputStream()));

            out = new PrintWriter(socket.getOutputStream());

            startReading();
            startWriting();
            
        } catch (Exception e) {
            
        }
    }

    public void startReading()
    {
            //thread = read karke deta rhega
            //Runnable is a thread  ,  r1 main readig ka code likhege 
            Runnable r1 = ()->{
                      System.out.println("reader started .. ");
                      try{
                      while(true){
                          
                         String msg=  br.readLine(); //this massage come from client
                         if(msg.equals("exit")){     //client ne jese hii exit kiya loop se bahar;
                             System.out.println("Server  has stoped the chat");
                             socket.close();
                             break; //reader will be stop.. 
                         } 
                         System.out.println("Server : "+ msg);
                        }
                      }catch(Exception e){
                         // e.printStackTrace();
                         System.out.println("Connection is closed ");
                      }
                    
            };
            new Thread(r1).start(); //this is for start the thread refreanc will be runnable 
    }

    public void startWriting()
    {
        //thread = data user se lega  and then send karega client tak
        //r2 is a second thread ,isme writing ka code likhege
        //this is for sending the data;
        Runnable r2 = ()->{
            System.out.println("typing..");
            try{
                   while( ! socket.isClosed()){
                              //br1 ki help se consol se data lena hai..
                              BufferedReader br1 =  new BufferedReader(new InputStreamReader(System.in));

                              String content = br1.readLine();
                              out.println(content);
                              out.flush();//sometime the data didnt go
                              if(content.equals("exit")){
                                     socket.close();
                                     break;
                              }


                   }
                       
                      // System.out.println("Connection is closed ");
                }
                       catch (Exception e) {
                          e.printStackTrace(); //consol pe exception ko print ke liye;
                       }

                   
        };

        //thread ko start krna hai to ; so create the object of the thread 
        new Thread(r2).start();


    }
    public static void main(String[] args){
        new Client();
    }
    
}
