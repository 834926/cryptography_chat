import java.net.*;
//import jdk.internal.org.jline.utils.InputStreamReader;

import java.io.*; //used for buffered  readder 
class Server
{      ServerSocket server;
       Socket socket;
       BufferedReader  br;  //br for reading 
       PrintWriter  out;   //out for writing
        

      public Server(){
          //this  is constructor all the program we will write in constructor
          try {
            server = new ServerSocket(7778);//you should tell the port in ();
            System.out.println("server is ready to accept the connection");
            System.out.println("waiting....");
            //jab tak request nhi aayegii iske aage nhi bdega 
            socket =  server.accept();  //accept the connection of socket

            br = new BufferedReader(new InputStreamReader(socket.getInputStream()));

            out = new PrintWriter(socket.getOutputStream());

            startReading();
            startWriting();


          } catch (Exception e) {
              e.printStackTrace();
              
          }
            

      } //this both the class run again and again 
      //so here we using muiltithreading 
      //this is for receiving the data;
      public void startReading()
      {
              //thread = read karke deta rhega
              //Runnable is a thread  ,  r1 main readig ka code likhege 
              Runnable r1 = ()->{
                        System.out.println("reader started .. ");
                        try{
                        while(true){
                            
                           String msg=  br.readLine(); //this massage come from client
                           if(msg.equals("exit")){     //client ne jese hii exit kiya loop se bahar;
                               System.out.println("Client has stoped the chat");
                               socket.close();
                               break; //reader will be stop.. 
                           } 
                           System.out.println("Client : "+ msg);
                        }}
                    catch(Exception e)
                
                    {
                       // e.printStackTrace();
                       System.out.println("Connection is closed ");
                    }

              };
              new Thread(r1).start(); //this is for start the thread refreanc will be runnable 
      }
      public void startWriting()
      {
          //thread = data user se lega  and then send karega client tak
          //r2 is a second thread ,isme writing ka code likhege
          //this is for sending the data;
          Runnable r2 = ()->{
              System.out.println("typing..");
              try{
                     while(true && !socket.isClosed()){
                                //br1 ki help se consol se data lena hai..
                                BufferedReader br1 =  new BufferedReader(new InputStreamReader(System.in));

                                String content = br1.readLine();
                                out.println(content);
                                out.flush();//sometime the data didnt go
                                if(content.equals("exit")){
                                    socket.close();
                                    break;
                                }
                                

                     }
                             
                         } catch (Exception e) {
                            //e.printStackTrace(); //consol pe exception ko print ke liye;
                            System.out.println("Connection is closed");
                         }
                       //  System.out.println("Connection is closed");

                     
          };

          //thread ko start krna hai to ; so create the object of the thread 
          new Thread(r2).start();


      }

    public static void main(String[]  args ){
        
        new Server();
    }
}